package com.sachin.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // all the buttons and text View
    private TextView mAnsView;
    private Button mdel;
    private Button mbtn0;
    private Button mbtn1;
    private Button mbtn2;
    private Button mbtn3;
    private Button mbtn4;
    private Button mbtn5;
    private Button mbtn6;
    private Button mbtn7;
    private Button mbtn8;
    private Button mbtn9;
    private Button mAdd;
    private Button mSub;
    private Button mMul;
    private Button mDiv;
    private Button mDec;
    private Button mEql;
    private Button mClose;
    private Button mOpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Declare all the event listners
        mAnsView = (TextView) findViewById(R.id.ansView);
        mbtn0 = (Button) findViewById(R.id.btn0);
        mbtn1 = (Button) findViewById(R.id.btn1);
        mbtn2 = (Button) findViewById(R.id.btn2);
        mbtn3 = (Button) findViewById(R.id.btn3);
        mbtn4 = (Button) findViewById(R.id.btn4);
        mbtn5 = (Button) findViewById(R.id.btn5);
        mbtn6 = (Button) findViewById(R.id.btn6);
        mbtn7 = (Button) findViewById(R.id.btn7);
        mbtn8 = (Button) findViewById(R.id.btn8);
        mbtn9 = (Button) findViewById(R.id.btn9);
        mDec = (Button) findViewById(R.id.btnDec);
        mAdd = (Button) findViewById(R.id.btnplus);
        mSub = (Button) findViewById(R.id.btnminus);
        mMul = (Button) findViewById(R.id.btmul);
        mDiv = (Button) findViewById(R.id.btndiv);
        mOpen = (Button) findViewById(R.id.btnOpen);
        mClose = (Button) findViewById(R.id.btnClose);
        mEql = (Button) findViewById(R.id.btnequal);
        mdel = (Button) findViewById(R.id.btnDel);


        mbtn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "0");
            }
        });


        mbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "1");
            }
        });

        mbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "2");
            }
        });

        mbtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "3");
            }
        });

        mbtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "4");
            }
        });

        mbtn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "5");
            }
        });

        mbtn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "6");
            }
        });

        mbtn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "7");
            }
        });

        mbtn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "8");
            }
        });

        mbtn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "9");
            }
        });

        mDec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + ".");
            }
        });

        mAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "+");

            }
        });

        mSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "-");

            }
        });

        mMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "*");

            }
        });

        mDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "/");

            }
        });

        mOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + "(");

            }
        });

        mClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAnsView.setText((String) mAnsView.getText() + ")");

            }
        });

        mdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = (String) mAnsView.getText();
                char [] carr = s.toCharArray();
                String a  = "";

                for(int i=0; i< carr.length-1; i++){
                    a += carr[i];
                }
                mAnsView.setText(a);

            }
        });

//
//        mEql.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String raw_exp = (String) mAnsView.getText();
//                char[] exp = raw_exp.toCharArray();
//                if (!isNumber(exp[0])) {
//                    mAnsView.setText("");
//                    Toast.makeText(getApplicationContext(), "Cannot put operator in first", Toast.LENGTH_SHORT).show();
//                }
//                ArrayList<BigDecimal> numbers = new ArrayList<>();
//                ArrayList<String> operators = new ArrayList<>();

//                String temp = "";
//                for (int i = 0; i < exp.length; i++) {
//                    if (isNumber(exp[i]) || exp[i] == '.') {
//                        temp  = temp + exp[i];
//                    }
//                    else{
//
//                    }
//                }
    }
//        });
//
//
//    }

    private boolean isNumber(char s) {
        switch (s) {
            case '0':
                return true;
            case '1':
                return true;
            case '2':
                return true;
            case '3':
                return true;
            case '4':
                return true;
            case '5':
                return true;
            case '6':
                return true;
            case '7':
                return true;
            case '8':
                return true;
            case '9':
                return true;
            default:
                return false;
        }
    }

    private boolean isOperator(char s) {
        switch (s) {
            case '+':
                return true;
            case '-':
                return true;
            case '*':
                return true;
            case '/':
                return true;
            case '(':
                return true;
            case ')':
                return true;
            default:
                return false;
        }
    }
}
